// Handle form toggling
const wrapper = document.querySelector('.wrapper');
const btnPopup = document.querySelector('.btnLogin-popup');
const informationVisible = document.querySelector('.information');

btnPopup.addEventListener('click', () => {
    window.location.href="register.html";
    informationVisible?.classList.remove("visible");
});

document.addEventListener("DOMContentLoaded", () => {
    const informationBox = document.querySelector(".information");
    const homeSection = document.querySelector("#home");
    setTimeout(() => {
        informationBox.classList.add("visible");
    }, 500);
    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    informationBox.classList.add("visible");
                } else {
                    informationBox.classList.remove("visible");
                }
            });
        },
        { threshold: 0.5 }
    );
    observer.observe(homeSection);
});


document.addEventListener("DOMContentLoaded", () => {
    const aboutSection = document.querySelector("#about");

    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    aboutSection.classList.add("visible");
                }
            });
        },
        {
            threshold: 0.05,// Trigger when 10% of the section is visible
        }
    );
    observer.observe(aboutSection);
});