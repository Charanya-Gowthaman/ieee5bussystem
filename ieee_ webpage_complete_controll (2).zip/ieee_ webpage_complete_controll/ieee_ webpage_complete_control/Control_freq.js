document.addEventListener("DOMContentLoaded", () => {
    console.log("DOM Fully Loaded");

    // Get DOM elements
    const automatic = document.getElementById("automatic");
    const manual = document.getElementById("manual");
    const mode = document.getElementById("currentmode");
    const showmanual = document.getElementById("manualcontrol");
    const showmanualreadings = document.getElementById("manualcontrolreadings");
    let region1on = document.getElementById("region1on");
    let region1off = document.getElementById("region1off");
    let region2on = document.getElementById("region2on");
    let region2off = document.getElementById("region2off");
    let region3on = document.getElementById("region3on");
    let region3off = document.getElementById("region3off");

    // Firebase Configuration
    const firebaseConfig = {
        apiKey: "AIzaSyBUwgFB8LFKRDdEb8Kuoi-r5hGE84KTTOE",
        authDomain: "ieee5bus.firebaseapp.com",
        databaseURL: "https://ieee5bus-default-rtdb.asia-southeast1.firebasedatabase.app",
        projectId: "ieee5bus",
        storageBucket: "ieee5bus.firebasestorage.app",
        messagingSenderId: "898983858467",
        appId: "1:898983858467:web:d7e17f2c9570be1275fc96"
    };

///////////////////   Initialize Firebase   //////////////////////
    firebase.initializeApp(firebaseConfig);
    const database = firebase.database();
    console.log("Firebase Initialized:", firebase.apps.length > 0 ? "Success" : "Failed");

    function updateControlField(field, value) {
        database.ref(`control/${field}`).set(value)
            .then(() => console.log(`${field} updated to`, value))
            .catch(error => console.error("Error updating Firebase:", error));
    }

/////////////////   Mode selection event listeners   //////////////////
    automatic.addEventListener("click", (event) => {
        event.preventDefault();
        mode.textContent = "Automatic";

        updateControlField("automatic", true);
        updateControlField("manual", false);

        showmanual.style.display = "none";
        showmanualreadings.style.display = "none";
    });

    manual.addEventListener("click", (event) => {
        event.preventDefault();
        mode.textContent = "Manual";

        updateControlField("manual", true);
        updateControlField("automatic", false);

        showmanual.style.display = showmanual.style.display === "none" ? "block" : "none";
        showmanualreadings.style.display = showmanualreadings.style.display === "none" ? "block" : "none";
    });

/////////////////////  Load shedding logic //////////////////////
let totalLoadShed = 0;
let regions = {
    region1: { "40W_A": false, "40W_B": false, "60W": false, "100W": false, total: 0 },
    region2: { "40W": false, "100W_A": false, "100W_B": false, total: 0 },
    region3: { "60W_A": false, "60W_B": false, "100W_A": false, "100W_B": false, total: 0 }
};

function updateLoadShed() {
    totalLoadShed = Object.values(regions).reduce((sum, r) => sum + r.total, 0);
    document.getElementById("loadshutdown").innerText = `${totalLoadShed} W`;
    database.ref("control/load_shed").set(totalLoadShed);
}

window.toggleRegion = function (region, key, power, turnOn) {
    if (turnOn) {
        // 
        if (!regions[region][key]) {
            regions[region][key] = true;
            regions[region].total += power;
        }
    } else {
        // Turn OFF only if it was ON before
        if (regions[region][key]) {
            regions[region][key] = false;
            regions[region].total -= power;
        }
    }

    updateLoadShed();
    database.ref(`control/${region}`).set(regions[region]);
};

const buttonMappings = [
    { id: "region140a", region: "region1", key: "40W_A", power: 40 },
    { id: "region140b", region: "region1", key: "40W_B", power: 40 },
    { id: "region160", region: "region1", key: "60W", power: 60 },
    { id: "region1100", region: "region1", key: "100W", power: 100 },
    { id: "region240", region: "region2", key: "40W", power: 40 },
    { id: "region2100a", region: "region2", key: "100W_A", power: 100 },
    { id: "region2100b", region: "region2", key: "100W_B", power: 100 },
    { id: "region360a", region: "region3", key: "60W_A", power: 60 },
    { id: "region360b", region: "region3", key: "60W_B", power: 60 },
    { id: "region3100a", region: "region3", key: "100W_A", power: 100 },
    { id: "region3100b", region: "region3", key: "100W_B", power: 100 },
];

buttonMappings.forEach(({ id, region, key, power }) => {
    const onButton = document.getElementById(`${id}on`);
    const offButton = document.getElementById(`${id}off`);

    if (onButton) onButton.addEventListener("click", () => toggleRegion(region, key, power, true));
    if (offButton) offButton.addEventListener("click", () => toggleRegion(region, key, power, false));
});

////////////////////   Fetch power and frequency readings  //////////////////////
    async function dataentry() {
        const latestData = {};
        for (const busNumber of [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]) {
            try {
                const snapshot = await database.ref(`meters/Unit_${busNumber}`).limitToLast(1).once("value");
                const data = snapshot.val();
                if (data) {
                    const latestTimestamp = Object.keys(data)[0]; // Get latest timestamp
                    const latestDataEntry = data[latestTimestamp]; // Retrieve latest data
                    if (!latestDataEntry) {
                        console.warn(`No valid data found for Unit_${busNumber}`);
                        continue;
                    }
                    latestData[busNumber] = {
                        frequency: latestDataEntry.Frequency ? latestDataEntry.Frequency.toFixed(3) : "N/A",
                        power: latestDataEntry.Power ? latestDataEntry.Power.toFixed(3) : "N/A",
                    };
                } else {
                    console.warn(`No data found for Unit_${busNumber}`);
                }
                if (latestData[busNumber]) {
                    const powerElement = document.getElementById(`power-${busNumber}`);
                    const freqElement = document.getElementById(`frequency-${busNumber}`);
                    if (powerElement) powerElement.textContent = latestData[busNumber].power;
                    if (freqElement) freqElement.textContent = latestData[busNumber].frequency;
                    console.log(`Data for Unit_${busNumber} updated successfully`);
                }
            } catch (error) {
                console.error(`Error fetching data for Unit_${busNumber}:`, error);
            }
        }
    }

    dataentry(); // Fetch data once on load
});

const close = document.getElementById('closebutton');

function closeFunction() {
    window.location.href = 'dashboard.html';
}

close.addEventListener('click', closeFunction);

// Navigation for Voltage Control Button
const vol_control = document.getElementById('volcontrol');
function vol_controlFunction() {
    window.location.href = 'Control_vol.html';
}
if (vol_control) {
    vol_control.addEventListener('click', vol_controlFunction);
}