document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('image-modal');
    modal.style.display = 'block'; // Show modal for debugging
});

let currentChart;

// Modal handling
const modal = document.getElementById('image-modal');
const closeModal = document.querySelector('.close-modal');

// Function to display the modal and chart
async function showImage(busNumber) {
    const data = await getdata(busNumber);

    if(busNumber>5){
        if(busNumber==6){
            document.getElementById('modal-title').textContent = `Chart for Line 1-2`;
        }
        else if(busNumber==7){
            document.getElementById('modal-title').textContent = `Chart for Line 1-3`;
        } 
        else if(busNumber==8){
            document.getElementById('modal-title').textContent = `Chart for Line 2-3`;
        }
        else if(busNumber==9){
            document.getElementById('modal-title').textContent = `Chart for Line 2-4`;
        }
        else if(busNumber==10){
            document.getElementById('modal-title').textContent = `Chart for Line 2-5`;
        }
        else if(busNumber==11){
            document.getElementById('modal-title').textContent = `Chart for Line 3-4`;
        }
        else{
            document.getElementById('modal-title').textContent = `Chart for Line 4-5`;
        }
    }
    else{
        document.getElementById('modal-title').textContent = `Chart for Bus ${busNumber}`;
    }

    const ctx = document.getElementById('graph').getContext('2d');
    if (currentChart) {
        currentChart.destroy();
    }

    // Chart data
    const data1 = {
        labels: data.xs,
        datasets: [{
            label: `Voltage Data`,
            data: data.vs,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1,
        },
        {
            label: `Power Data`,
            data: data.ps,
            backgroundColor: 'rgba(255, 26, 104, 0.2)',
            borderColor: 'rgba(255, 26, 104, 1)',
            borderWidth: 1,
        },
        {
            label: `Current Data`,
            data: data.cs,
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1,
        }]
    };

    //Create New Chart
    currentChart = new Chart(ctx, {
        type: 'line',
        data: data1,
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Parameters',
                        align: 'center',
                        font: { size: 16 },
                    },
                },
                x: {
                    title: {
                        display: true,
                        text: 'Time',
                        align: 'center',
                        font: { size: 16 },
                    },
                },
            },
        },
    });
}

// Check Firebase SDK
console.log("Checking Firebase...");
if (typeof firebase !== "undefined") {
    console.log("Firebase SDK Loaded");
} else {
    console.error("Firebase SDK NOT Loaded. Check your HTML script tags.");
}

// Firebase configuration for IEEE 5-Bus System
const firebaseConfig = {
    apiKey: "AIzaSyBUwgFB8LFKRDdEb8Kuoi-r5hGE84KTTOE",
    authDomain: "ieee5bus.firebaseapp.com",
    databaseURL: "https://ieee5bus-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "ieee5bus",
    storageBucket: "ieee5bus.firebasestorage.app",
    messagingSenderId: "898983858467",
    appId: "1:898983858467:web:d7e17f2c9570be1275fc96"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();

console.log("Firebase Initialized:", firebase.apps.length > 0 ? "Success" : "Failed");

async function getdata(busNumber) {
    const xs = [];
    const vs = [];
    const ps = [];
    const cs = [];

    try {
        const snapshot = await database.ref(`meters/Unit_${busNumber}`).limitToLast(100).once("value");
        const data = snapshot.val();

        if (data) {
            Object.keys(data).forEach(timestamp => {
                const entry = data[timestamp];
                const time = timestamp.slice(8, 10) + ":" + timestamp.slice(10, 12) + ":" + timestamp.slice(12, 14); // Extract HH:MM:SS
                xs.push(time);
                vs.push(entry.Voltage_AN || 0);
                ps.push(entry.Power || 0);
                cs.push(entry.Current || 0);
            });
        } else {
            console.warn(`No historical data found for Unit_${busNumber}`);
        }
    } catch (error) {
        console.error(`Error fetching historical data for Unit_${busNumber}:`, error);
    }

    return { xs, vs, ps, cs };
}

async function dataentry(busNumber) {
    console.log(`Fetching real-time data for Unit_${busNumber}...`);

    if(busNumber>5){
        if(busNumber==6){
            document.getElementById('modal-bus-id').textContent = `Meter Reading: Line 1-2`;
        }
        else if(busNumber==7){
            document.getElementById('modal-bus-id').textContent = `Meter Reading: Line 1-3`;
        } 
        else if(busNumber==8){
            document.getElementById('modal-bus-id').textContent = `Meter Reading: Line 2-3`;
        }
        else if(busNumber==9){
            document.getElementById('modal-bus-id').textContent = `Meter Reading: Line 2-4`;
        }
        else if(busNumber==10){
            document.getElementById('modal-bus-id').textContent = `Meter Reading: Line 2-5`;
        }
        else if(busNumber==11){
            document.getElementById('modal-bus-id').textContent = `Meter Reading: Line 3-4`;
        }
        else{
            document.getElementById('modal-bus-id').textContent = `Meter Reading: Line 4-5`;
        }
    }
    else{
        document.getElementById('modal-bus-id').textContent = `Meter Reading: Bus ${busNumber}`;
    }

    try {
        database.ref(`meters/Unit_${busNumber}`).limitToLast(1).on("value", (snapshot) => {
            const data = snapshot.val();
            if (data) {
                console.log("Realtime Data Retrieved:", data);
                const latestTimestamp = Object.keys(data)[0]; // Get latest timestamp key
                const latestData = data[latestTimestamp]; // Access the latest data entry

                if (!latestData) {
                    console.warn(`No valid data found for Unit_${busNumber}`);
                    return;
                }

                // Use correct Firebase keys and prevent errors
                document.getElementById("voltageln").textContent = latestData.Voltage_AN ? latestData.Voltage_AN.toFixed(3) : "N/A";
                document.getElementById("current").textContent = latestData.Current ? latestData.Current.toFixed(3) : "N/A";
                document.getElementById("power").textContent = latestData.Power ? latestData.Power.toFixed(3) : "N/A";
                document.getElementById("frequency").textContent = latestData.Frequency ? latestData.Frequency.toFixed(3) : "N/A";
                document.getElementById("powerfactor").textContent = latestData.PowerFactor ? latestData.PowerFactor.toFixed(3) : "N/A";
            } else {
                console.warn(`No data found for Unit_${busNumber}`);
            }
        });
    } catch (error) {
        console.error(`Error fetching real-time data for Unit_${busNumber}:`, error);
    }
}


//dOWNLOADDDDDDD CSVVV
document.getElementById("csv-download-btn").addEventListener("click", async () => {
    const params = new URLSearchParams(window.location.search);
    const busNumber = params.get('bus');

    if (!busNumber) {
        alert("No unit selected for download!");
        return;
    }

    try {
        const snapshot = await database.ref(`meters/Unit_${busNumber}`).limitToLast(50).once("value");
        const data = snapshot.val();

        if (!data) {
            alert(`No data available for Unit_${busNumber}`);
            return;
        }

        let unitData = [];

        Object.keys(data).forEach(timestamp => {
            const entry = data[timestamp];

            unitData.push({
                Timestamp: entry.Timestamp || timestamp,
                Voltage_AN: entry.Voltage_AN || "N/A",
                Current: entry.Current || "N/A",
                PowerFactor: entry.PowerFactor || "N/A",
                Power: entry.Power || "N/A",
                Frequency: entry.Frequency || "N/A"
            });
        });

        // Convert to CSV and download
        const csvData = convertToCSV(unitData);
        downloadCSV(csvData, `Unit_${busNumber}.csv`);

    } catch (error) {
        console.error(`Error fetching data for Unit_${busNumber}:`, error);
    }
});

function convertToCSV(data) {
    const headers = Object.keys(data[0]);
    const csvRows = [headers.join(",")];

    data.forEach(entry => {
        const values = headers.map(header => entry[header]);
        csvRows.push(values.join(","));
    });

    return csvRows.join("\n");
}

function downloadCSV(csvData, filename) {
    const blob = new Blob([csvData], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Close modal function
function closeModalFunction() {
    window.location.href = "dashboard.html";
}

closeModal.addEventListener('click', closeModalFunction);

document.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);
    const busNumber = params.get('bus');
    if (busNumber) {
        showImage(busNumber);
        dataentry(busNumber);
    }
});
