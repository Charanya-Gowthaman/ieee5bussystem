from pymodbus.client import ModbusSerialClient as ModbusClient
from pymodbus.constants import Endian
from pymodbus.payload import BinaryPayloadDecoder
import time
import csv
import os

# List of unit IDs for each meter
UNIT_IDS = [0x1, 0x2, 0x3, 0x4, 0x5,0x6,0x7,0x8,0x9,0xA,0xB,0xC]

# Directory to store the CSV files
CSV_DIRECTORY = "code"
os.makedirs(CSV_DIRECTORY, exist_ok=True)

# Initialize CSV files with headers for each Unit ID
for unit in UNIT_IDS:
    file_path = os.path.join(CSV_DIRECTORY, f"Unit_{unit}.csv")
    if not os.path.exists(file_path):  # Only create if the file doesn't already exist
        with open(file_path, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['Timestamp', 'Voltage l-N', 'Frequency', 'Power Factor', 'Power', 'Current'])  # Header row

def read_meter_data(client, unit):
    try:
        # Read Voltage A-N
        response = client.read_holding_registers(3926, 2, slave=unit)
        voltage_ln = None
        if not response.isError():
            decoder = BinaryPayloadDecoder.fromRegisters(response.registers, byteorder=Endian.Big, wordorder=Endian.Little)
            voltage_ln = decoder.decode_32bit_float()
            print(f"Voltage L-N (Unit {unit}): {voltage_ln}")

        # Read Frequency
        response = client.read_holding_registers(3914, 2,slave=unit)
        frequency = None
        if not response.isError():
            decoder = BinaryPayloadDecoder.fromRegisters(response.registers, byteorder=Endian.Big, wordorder=Endian.Little)
            frequency = decoder.decode_32bit_float()
            print(f"Frequency (Unit {unit}): {frequency}")

        # Read Power Factor
        response = client.read_holding_registers(3906, 2, slave=unit)
        powerfactor = None
        if not response.isError():
            decoder = BinaryPayloadDecoder.fromRegisters(response.registers, byteorder=Endian.Big, wordorder=Endian.Little)
            powerfactor = decoder.decode_32bit_float()
            print(f"Power Factor (Unit {unit}): {powerfactor}")

        # Read Power
        response = client.read_holding_registers(3902, 2, slave=unit)
        power = None
        if not response.isError():
            decoder = BinaryPayloadDecoder.fromRegisters(response.registers, byteorder=Endian.Big, wordorder=Endian.Little)
            power = decoder.decode_32bit_float()
            print(f"Active Power (Unit {unit}): {power}")
        
        response = client.read_holding_registers(3912, 2, slave=unit)
        current = None
        if not response.isError():
            decoder = BinaryPayloadDecoder.fromRegisters(response.registers, byteorder=Endian.Big, wordorder=Endian.Little)
            current = decoder.decode_32bit_float()
            print(f"Current (Unit {unit}): {current}")

        # Write data to the respective CSV file
        file_path = os.path.join(CSV_DIRECTORY, f"Unit_{unit}.csv")
        with open(file_path, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), voltage_ln, frequency, powerfactor, power, current])
        print(f"Data for Unit {unit} written to CSV")

    except Exception as e:
        print(f"Exception for Unit {unit}: {e}")

# Modbus client setup
client = ModbusClient(method="rtu", port="/dev/ttyUSB0", stopbits=1, bytesize=8, parity='E', baudrate=19200)

try:
    while True:
        client.connect()
        for unit in UNIT_IDS:
            read_meter_data(client, unit)
        client.close()
        time.sleep(10)
except KeyboardInterrupt:
    print("Process interrupted by user.")
finally:
    client.close()
